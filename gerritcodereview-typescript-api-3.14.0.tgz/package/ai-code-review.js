/**
 * Enum for AI chat Action types.
 */
export var ActionEnum;
(function (ActionEnum) {
    ActionEnum[ActionEnum["ACTION_UNSPECIFIED"] = 0] = "ACTION_UNSPECIFIED";
    ActionEnum[ActionEnum["ACTION_FREE_CHAT"] = 1] = "ACTION_FREE_CHAT";
    ActionEnum[ActionEnum["ACTION_EXPLAIN_CODE"] = 2] = "ACTION_EXPLAIN_CODE";
    ActionEnum[ActionEnum["ACTION_IMPROVE_CODE"] = 3] = "ACTION_IMPROVE_CODE";
    // 4 and 5 are deprecated.
    // ACTION_CUSTOM indicates that the user selected a custom action. In which
    // case the action is determined by a `custom_action_id` that is set in the
    // request.
    ActionEnum[ActionEnum["ACTION_CUSTOM"] = 6] = "ACTION_CUSTOM";
    ActionEnum[ActionEnum["ACTION_EXPLAIN_BUG"] = 7] = "ACTION_EXPLAIN_BUG";
    ActionEnum[ActionEnum["ACTION_SUMMARIZE"] = 8] = "ACTION_SUMMARIZE";
    ActionEnum[ActionEnum["ACTION_ISSUE_FINDING"] = 9] = "ACTION_ISSUE_FINDING";
    ActionEnum[ActionEnum["ACTION_HELP_REVIEW"] = 10] = "ACTION_HELP_REVIEW";
    ActionEnum[ActionEnum["ACTION_CL_GOAL"] = 11] = "ACTION_CL_GOAL";
})(ActionEnum || (ActionEnum = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWktY29kZS1yZXZpZXcuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJhaS1jb2RlLXJldmlldy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFlQTs7R0FFRztBQUNILE1BQU0sQ0FBTixJQUFZLFVBZ0JYO0FBaEJELFdBQVksVUFBVTtJQUNwQix1RUFBc0IsQ0FBQTtJQUN0QixtRUFBb0IsQ0FBQTtJQUNwQix5RUFBdUIsQ0FBQTtJQUN2Qix5RUFBdUIsQ0FBQTtJQUN2QiwwQkFBMEI7SUFFMUIsMkVBQTJFO0lBQzNFLDJFQUEyRTtJQUMzRSxXQUFXO0lBQ1gsNkRBQWlCLENBQUE7SUFDakIsdUVBQXNCLENBQUE7SUFDdEIsbUVBQW9CLENBQUE7SUFDcEIsMkVBQXdCLENBQUE7SUFDeEIsd0VBQXVCLENBQUE7SUFDdkIsZ0VBQW1CLENBQUE7QUFDckIsQ0FBQyxFQWhCVyxVQUFVLEtBQVYsVUFBVSxRQWdCckIifQ==