export var ActionType;
(function (ActionType) {
    ActionType["CHANGE"] = "change";
    ActionType["REVISION"] = "revision";
})(ActionType || (ActionType = {}));
// This is used for sorting the actions, BUT:
// * For showing up as a dedicated button the action must not be hidden and not
//   be an overflow action. See setActionOverflow() and setActionHidden().
// * All primary actions are shown left of all secondary actions. By default
//   the primary actions are: "Submit" and "Mark as active".
//
// Also note that a LOWER value means HIGHER priority!
export var ActionPriority;
(function (ActionPriority) {
    ActionPriority[ActionPriority["CHANGE"] = 3] = "CHANGE";
    // Only "Submit" and "Code-Review" buttons should show before "Chat".
    ActionPriority[ActionPriority["CHAT"] = 1] = "CHAT";
    ActionPriority[ActionPriority["DEFAULT"] = 0] = "DEFAULT";
    // This is a bit confusing, because this is the LOWEST priority in the list.
    // But it does not matter much, because the `primary` property is evaluated
    // first, and then the `priority` does not matter anymore.
    ActionPriority[ActionPriority["PRIMARY"] = 4] = "PRIMARY";
    // This means that the "Code-Review" voting button is the left most button,
    // if there are no primary actions.
    ActionPriority[ActionPriority["REVIEW"] = -3] = "REVIEW";
    ActionPriority[ActionPriority["REVISION"] = 2] = "REVISION";
})(ActionPriority || (ActionPriority = {}));
export var ChangeActions;
(function (ChangeActions) {
    ChangeActions["ABANDON"] = "abandon";
    ChangeActions["DELETE"] = "/";
    ChangeActions["DELETE_EDIT"] = "deleteEdit";
    ChangeActions["EDIT"] = "edit";
    ChangeActions["FOLLOW_UP"] = "followup";
    ChangeActions["MOVE"] = "move";
    ChangeActions["PRIVATE"] = "private";
    ChangeActions["PRIVATE_DELETE"] = "private.delete";
    ChangeActions["PUBLISH_EDIT"] = "publishEdit";
    ChangeActions["REBASE"] = "rebase";
    ChangeActions["REBASE_EDIT"] = "rebaseEdit";
    ChangeActions["READY"] = "ready";
    ChangeActions["RESTORE"] = "restore";
    ChangeActions["REVERT"] = "revert";
    ChangeActions["REVERT_SUBMISSION"] = "revert_submission";
    ChangeActions["REVIEWED"] = "reviewed";
    ChangeActions["STOP_EDIT"] = "stopEdit";
    ChangeActions["SUBMIT"] = "submit";
    ChangeActions["UNREVIEWED"] = "unreviewed";
    ChangeActions["WIP"] = "wip";
    ChangeActions["INCLUDED_IN"] = "includedIn";
})(ChangeActions || (ChangeActions = {}));
export var RevisionActions;
(function (RevisionActions) {
    RevisionActions["CHERRYPICK"] = "cherrypick";
    RevisionActions["REBASE"] = "rebase";
    RevisionActions["SUBMIT"] = "submit";
    RevisionActions["DOWNLOAD"] = "download";
})(RevisionActions || (RevisionActions = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hhbmdlLWFjdGlvbnMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJjaGFuZ2UtYWN0aW9ucy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFlQSxNQUFNLENBQU4sSUFBWSxVQUdYO0FBSEQsV0FBWSxVQUFVO0lBQ3BCLCtCQUFpQixDQUFBO0lBQ2pCLG1DQUFxQixDQUFBO0FBQ3ZCLENBQUMsRUFIVyxVQUFVLEtBQVYsVUFBVSxRQUdyQjtBQUVELDZDQUE2QztBQUM3QywrRUFBK0U7QUFDL0UsMEVBQTBFO0FBQzFFLDRFQUE0RTtBQUM1RSw0REFBNEQ7QUFDNUQsRUFBRTtBQUNGLHNEQUFzRDtBQUN0RCxNQUFNLENBQU4sSUFBWSxjQWFYO0FBYkQsV0FBWSxjQUFjO0lBQ3hCLHVEQUFVLENBQUE7SUFDVixxRUFBcUU7SUFDckUsbURBQVEsQ0FBQTtJQUNSLHlEQUFXLENBQUE7SUFDWCw0RUFBNEU7SUFDNUUsMkVBQTJFO0lBQzNFLDBEQUEwRDtJQUMxRCx5REFBVyxDQUFBO0lBQ1gsMkVBQTJFO0lBQzNFLG1DQUFtQztJQUNuQyx3REFBVyxDQUFBO0lBQ1gsMkRBQVksQ0FBQTtBQUNkLENBQUMsRUFiVyxjQUFjLEtBQWQsY0FBYyxRQWF6QjtBQUVELE1BQU0sQ0FBTixJQUFZLGFBc0JYO0FBdEJELFdBQVksYUFBYTtJQUN2QixvQ0FBbUIsQ0FBQTtJQUNuQiw2QkFBWSxDQUFBO0lBQ1osMkNBQTBCLENBQUE7SUFDMUIsOEJBQWEsQ0FBQTtJQUNiLHVDQUFzQixDQUFBO0lBQ3RCLDhCQUFhLENBQUE7SUFDYixvQ0FBbUIsQ0FBQTtJQUNuQixrREFBaUMsQ0FBQTtJQUNqQyw2Q0FBNEIsQ0FBQTtJQUM1QixrQ0FBaUIsQ0FBQTtJQUNqQiwyQ0FBMEIsQ0FBQTtJQUMxQixnQ0FBZSxDQUFBO0lBQ2Ysb0NBQW1CLENBQUE7SUFDbkIsa0NBQWlCLENBQUE7SUFDakIsd0RBQXVDLENBQUE7SUFDdkMsc0NBQXFCLENBQUE7SUFDckIsdUNBQXNCLENBQUE7SUFDdEIsa0NBQWlCLENBQUE7SUFDakIsMENBQXlCLENBQUE7SUFDekIsNEJBQVcsQ0FBQTtJQUNYLDJDQUEwQixDQUFBO0FBQzVCLENBQUMsRUF0QlcsYUFBYSxLQUFiLGFBQWEsUUFzQnhCO0FBRUQsTUFBTSxDQUFOLElBQVksZUFLWDtBQUxELFdBQVksZUFBZTtJQUN6Qiw0Q0FBeUIsQ0FBQTtJQUN6QixvQ0FBaUIsQ0FBQTtJQUNqQixvQ0FBaUIsQ0FBQTtJQUNqQix3Q0FBcUIsQ0FBQTtBQUN2QixDQUFDLEVBTFcsZUFBZSxLQUFmLGVBQWUsUUFLMUIifQ==