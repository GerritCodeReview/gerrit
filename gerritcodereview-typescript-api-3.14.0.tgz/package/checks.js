export var ResponseCode;
(function (ResponseCode) {
    ResponseCode["OK"] = "OK";
    ResponseCode["ERROR"] = "ERROR";
    ResponseCode["NOT_LOGGED_IN"] = "NOT_LOGGED_IN";
})(ResponseCode || (ResponseCode = {}));
/**
 * Action names that get special UI treatment.
 */
export const USEFUL = 'useful';
export const NOT_USEFUL = 'not-useful';
/** See CheckRun.status for documentation. */
export var RunStatus;
(function (RunStatus) {
    RunStatus["RUNNABLE"] = "RUNNABLE";
    RunStatus["RUNNING"] = "RUNNING";
    RunStatus["SCHEDULED"] = "SCHEDULED";
    RunStatus["COMPLETED"] = "COMPLETED";
})(RunStatus || (RunStatus = {}));
export var Category;
(function (Category) {
    Category["SUCCESS"] = "SUCCESS";
    Category["INFO"] = "INFO";
    Category["WARNING"] = "WARNING";
    Category["ERROR"] = "ERROR";
})(Category || (Category = {}));
// TBD: Clarify standard colors for common tags.
export var TagColor;
(function (TagColor) {
    TagColor["GRAY"] = "gray";
    TagColor["YELLOW"] = "yellow";
    TagColor["PINK"] = "pink";
    TagColor["PURPLE"] = "purple";
    TagColor["CYAN"] = "cyan";
    TagColor["BROWN"] = "brown";
})(TagColor || (TagColor = {}));
export var LinkIcon;
(function (LinkIcon) {
    LinkIcon["EXTERNAL"] = "external";
    LinkIcon["IMAGE"] = "image";
    LinkIcon["HISTORY"] = "history";
    LinkIcon["DOWNLOAD"] = "download";
    LinkIcon["DOWNLOAD_MOBILE"] = "download_mobile";
    LinkIcon["HELP_PAGE"] = "help_page";
    LinkIcon["REPORT_BUG"] = "report_bug";
    LinkIcon["CODE"] = "code";
    LinkIcon["FILE_PRESENT"] = "file_present";
    LinkIcon["VIEW_TIMELINE"] = "view_timeline";
})(LinkIcon || (LinkIcon = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hlY2tzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiY2hlY2tzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQXFHQSxNQUFNLENBQU4sSUFBWSxZQUlYO0FBSkQsV0FBWSxZQUFZO0lBQ3RCLHlCQUFTLENBQUE7SUFDVCwrQkFBZSxDQUFBO0lBQ2YsK0NBQStCLENBQUE7QUFDakMsQ0FBQyxFQUpXLFlBQVksS0FBWixZQUFZLFFBSXZCO0FBOEtEOztHQUVHO0FBQ0gsTUFBTSxDQUFDLE1BQU0sTUFBTSxHQUFHLFFBQVEsQ0FBQztBQUMvQixNQUFNLENBQUMsTUFBTSxVQUFVLEdBQUcsWUFBWSxDQUFDO0FBbUR2Qyw2Q0FBNkM7QUFDN0MsTUFBTSxDQUFOLElBQVksU0FLWDtBQUxELFdBQVksU0FBUztJQUNuQixrQ0FBcUIsQ0FBQTtJQUNyQixnQ0FBbUIsQ0FBQTtJQUNuQixvQ0FBdUIsQ0FBQTtJQUN2QixvQ0FBdUIsQ0FBQTtBQUN6QixDQUFDLEVBTFcsU0FBUyxLQUFULFNBQVMsUUFLcEI7QUFzSkQsTUFBTSxDQUFOLElBQVksUUFLWDtBQUxELFdBQVksUUFBUTtJQUNsQiwrQkFBbUIsQ0FBQTtJQUNuQix5QkFBYSxDQUFBO0lBQ2IsK0JBQW1CLENBQUE7SUFDbkIsMkJBQWUsQ0FBQTtBQUNqQixDQUFDLEVBTFcsUUFBUSxLQUFSLFFBQVEsUUFLbkI7QUFRRCxnREFBZ0Q7QUFDaEQsTUFBTSxDQUFOLElBQVksUUFPWDtBQVBELFdBQVksUUFBUTtJQUNsQix5QkFBYSxDQUFBO0lBQ2IsNkJBQWlCLENBQUE7SUFDakIseUJBQWEsQ0FBQTtJQUNiLDZCQUFpQixDQUFBO0lBQ2pCLHlCQUFhLENBQUE7SUFDYiwyQkFBZSxDQUFBO0FBQ2pCLENBQUMsRUFQVyxRQUFRLEtBQVIsUUFBUSxRQU9uQjtBQW9CRCxNQUFNLENBQU4sSUFBWSxRQVdYO0FBWEQsV0FBWSxRQUFRO0lBQ2xCLGlDQUFxQixDQUFBO0lBQ3JCLDJCQUFlLENBQUE7SUFDZiwrQkFBbUIsQ0FBQTtJQUNuQixpQ0FBcUIsQ0FBQTtJQUNyQiwrQ0FBbUMsQ0FBQTtJQUNuQyxtQ0FBdUIsQ0FBQTtJQUN2QixxQ0FBeUIsQ0FBQTtJQUN6Qix5QkFBYSxDQUFBO0lBQ2IseUNBQTZCLENBQUE7SUFDN0IsMkNBQStCLENBQUE7QUFDakMsQ0FBQyxFQVhXLFFBQVEsS0FBUixRQUFRLFFBV25CIn0=