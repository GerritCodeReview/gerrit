/**
 * @fileoverview Core API types for Gerrit.
 *
 * Core types are types used in many places in Gerrit, such as the Side enum.
 *
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Return type for cursor moves, that indicate whether a move was possible.
 */
export var CursorMoveResult;
(function (CursorMoveResult) {
    /** The cursor was successfully moved. */
    CursorMoveResult[CursorMoveResult["MOVED"] = 0] = "MOVED";
    /** There were no stops - the cursor was reset. */
    CursorMoveResult[CursorMoveResult["NO_STOPS"] = 1] = "NO_STOPS";
    /**
     * There was no more matching stop to move to - the cursor was clipped to the
     * end.
     */
    CursorMoveResult[CursorMoveResult["CLIPPED"] = 2] = "CLIPPED";
    /** The abort condition would have been fulfilled for the new target. */
    CursorMoveResult[CursorMoveResult["ABORTED"] = 3] = "ABORTED";
})(CursorMoveResult || (CursorMoveResult = {}));
/** A sentinel that can be inserted to disallow moving across. */
export class AbortStop {
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29yZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImNvcmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7O0dBUUc7QUFFSDs7R0FFRztBQUNILE1BQU0sQ0FBTixJQUFZLGdCQVlYO0FBWkQsV0FBWSxnQkFBZ0I7SUFDMUIseUNBQXlDO0lBQ3pDLHlEQUFLLENBQUE7SUFDTCxrREFBa0Q7SUFDbEQsK0RBQVEsQ0FBQTtJQUNSOzs7T0FHRztJQUNILDZEQUFPLENBQUE7SUFDUCx3RUFBd0U7SUFDeEUsNkRBQU8sQ0FBQTtBQUNULENBQUMsRUFaVyxnQkFBZ0IsS0FBaEIsZ0JBQWdCLFFBWTNCO0FBRUQsaUVBQWlFO0FBQ2pFLE1BQU0sT0FBTyxTQUFTO0NBQUcifQ==