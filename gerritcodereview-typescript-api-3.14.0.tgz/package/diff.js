/**
 * @fileoverview The API of Gerrit's diff viewer, gr-diff.
 *
 * This includes some types which are also defined as part of Gerrit's JSON API
 * which are used as inputs to gr-diff.
 *
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Diff type in preferences
 * https://gerrit-review.googlesource.com/Documentation/rest-api-accounts.html#preferences-input
 */
export var DiffViewMode;
(function (DiffViewMode) {
    DiffViewMode["SIDE_BY_SIDE"] = "SIDE_BY_SIDE";
    DiffViewMode["UNIFIED"] = "UNIFIED_DIFF";
})(DiffViewMode || (DiffViewMode = {}));
export var Side;
(function (Side) {
    Side["LEFT"] = "left";
    Side["RIGHT"] = "right";
})(Side || (Side = {}));
export var CoverageType;
(function (CoverageType) {
    /**
     * start_character and end_character of the range will be ignored for this
     * type.
     */
    CoverageType["COVERED"] = "COVERED";
    /**
     * start_character and end_character of the range will be ignored for this
     * type.
     */
    CoverageType["NOT_COVERED"] = "NOT_COVERED";
    CoverageType["PARTIALLY_COVERED"] = "PARTIALLY_COVERED";
    /**
     * You don't have to use this. If there is no coverage information for a
     * range, then it implicitly means NOT_INSTRUMENTED. start_character and
     * end_character of the range will be ignored for this type.
     */
    CoverageType["NOT_INSTRUMENTED"] = "NOT_INSTRUMENTED";
})(CoverageType || (CoverageType = {}));
export const FILE = 'FILE';
export const LOST = 'LOST';
/** All types of button for expanding diff sections */
export var ContextButtonType;
(function (ContextButtonType) {
    ContextButtonType["ABOVE"] = "above";
    ContextButtonType["BELOW"] = "below";
    ContextButtonType["BLOCK_ABOVE"] = "block-above";
    ContextButtonType["BLOCK_BELOW"] = "block-below";
    ContextButtonType["ALL"] = "all";
})(ContextButtonType || (ContextButtonType = {}));
export var GrDiffLineType;
(function (GrDiffLineType) {
    GrDiffLineType["ADD"] = "add";
    GrDiffLineType["BOTH"] = "both";
    GrDiffLineType["BLANK"] = "blank";
    GrDiffLineType["REMOVE"] = "remove";
})(GrDiffLineType || (GrDiffLineType = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGlmZi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmYudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7OztHQVNHO0FBS0g7OztHQUdHO0FBQ0gsTUFBTSxDQUFOLElBQVksWUFHWDtBQUhELFdBQVksWUFBWTtJQUN0Qiw2Q0FBNkIsQ0FBQTtJQUM3Qix3Q0FBd0IsQ0FBQTtBQUMxQixDQUFDLEVBSFcsWUFBWSxLQUFaLFlBQVksUUFHdkI7QUFnUkQsTUFBTSxDQUFOLElBQVksSUFHWDtBQUhELFdBQVksSUFBSTtJQUNkLHFCQUFhLENBQUE7SUFDYix1QkFBZSxDQUFBO0FBQ2pCLENBQUMsRUFIVyxJQUFJLEtBQUosSUFBSSxRQUdmO0FBRUQsTUFBTSxDQUFOLElBQVksWUFrQlg7QUFsQkQsV0FBWSxZQUFZO0lBQ3RCOzs7T0FHRztJQUNILG1DQUFtQixDQUFBO0lBQ25COzs7T0FHRztJQUNILDJDQUEyQixDQUFBO0lBQzNCLHVEQUF1QyxDQUFBO0lBQ3ZDOzs7O09BSUc7SUFDSCxxREFBcUMsQ0FBQTtBQUN2QyxDQUFDLEVBbEJXLFlBQVksS0FBWixZQUFZLFFBa0J2QjtBQStCRCxNQUFNLENBQUMsTUFBTSxJQUFJLEdBQWUsTUFBTSxDQUFDO0FBQ3ZDLE1BQU0sQ0FBQyxNQUFNLElBQUksR0FBZSxNQUFNLENBQUM7QUFzRHZDLHNEQUFzRDtBQUN0RCxNQUFNLENBQU4sSUFBWSxpQkFNWDtBQU5ELFdBQVksaUJBQWlCO0lBQzNCLG9DQUFlLENBQUE7SUFDZixvQ0FBZSxDQUFBO0lBQ2YsZ0RBQTJCLENBQUE7SUFDM0IsZ0RBQTJCLENBQUE7SUFDM0IsZ0NBQVcsQ0FBQTtBQUNiLENBQUMsRUFOVyxpQkFBaUIsS0FBakIsaUJBQWlCLFFBTTVCO0FBa0NELE1BQU0sQ0FBTixJQUFZLGNBS1g7QUFMRCxXQUFZLGNBQWM7SUFDeEIsNkJBQVcsQ0FBQTtJQUNYLCtCQUFhLENBQUE7SUFDYixpQ0FBZSxDQUFBO0lBQ2YsbUNBQWlCLENBQUE7QUFDbkIsQ0FBQyxFQUxXLGNBQWMsS0FBZCxjQUFjLFFBS3pCIn0=