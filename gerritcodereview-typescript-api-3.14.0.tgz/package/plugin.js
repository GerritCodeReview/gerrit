export var TargetElement;
(function (TargetElement) {
    TargetElement["CHANGE_ACTIONS"] = "changeactions";
    TargetElement["REPLY_DIALOG"] = "replydialog";
})(TargetElement || (TargetElement = {}));
// Note: for new events, naming convention should be: `a-b`
export var EventType;
(function (EventType) {
    EventType["BEFORE_CHANGE_ACTION"] = "before-change-action";
    EventType["LABEL_CHANGE"] = "labelchange";
    EventType["SHOW_CHANGE"] = "showchange";
    EventType["SUBMIT_CHANGE"] = "submitchange";
    // Fires GerritView values such as 'change', 'dashboard', 'admin', ...
    EventType["VIEW_CHANGE"] = "view-change";
    EventType["SHOW_REVISION_ACTIONS"] = "show-revision-actions";
    EventType["BEFORE_COMMIT_MSG_EDIT"] = "before-commit-msg-edit";
    EventType["COMMIT_MSG_EDIT"] = "commitmsgedit";
    EventType["CUSTOM_EMOJIS"] = "custom-emojis";
    EventType["REVERT"] = "revert";
    EventType["REVERT_SUBMISSION"] = "revert_submission";
    EventType["POST_REVERT"] = "postrevert";
    EventType["ADMIN_MENU_LINKS"] = "admin-menu-links";
    EventType["SHOW_DIFF"] = "showdiff";
    EventType["BEFORE_REPLY_SENT"] = "before-reply-sent";
    EventType["REPLY_SENT"] = "replysent";
    EventType["BEFORE_PUBLISH_EDIT"] = "before-publish-edit";
    EventType["PUBLISH_EDIT"] = "publish-edit";
    EventType["BEFORE_REBASE"] = "before-rebase";
    EventType["BEFORE_CHERRY_PICK"] = "before-cherry-pick";
})(EventType || (EventType = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGx1Z2luLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicGx1Z2luLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQXNCQSxNQUFNLENBQU4sSUFBWSxhQUdYO0FBSEQsV0FBWSxhQUFhO0lBQ3ZCLGlEQUFnQyxDQUFBO0lBQ2hDLDZDQUE0QixDQUFBO0FBQzlCLENBQUMsRUFIVyxhQUFhLEtBQWIsYUFBYSxRQUd4QjtBQUVELDJEQUEyRDtBQUMzRCxNQUFNLENBQU4sSUFBWSxTQXNCWDtBQXRCRCxXQUFZLFNBQVM7SUFDbkIsMERBQTZDLENBQUE7SUFDN0MseUNBQTRCLENBQUE7SUFDNUIsdUNBQTBCLENBQUE7SUFDMUIsMkNBQThCLENBQUE7SUFDOUIsc0VBQXNFO0lBQ3RFLHdDQUEyQixDQUFBO0lBQzNCLDREQUErQyxDQUFBO0lBQy9DLDhEQUFpRCxDQUFBO0lBQ2pELDhDQUFpQyxDQUFBO0lBQ2pDLDRDQUErQixDQUFBO0lBQy9CLDhCQUFpQixDQUFBO0lBQ2pCLG9EQUF1QyxDQUFBO0lBQ3ZDLHVDQUEwQixDQUFBO0lBQzFCLGtEQUFxQyxDQUFBO0lBQ3JDLG1DQUFzQixDQUFBO0lBQ3RCLG9EQUF1QyxDQUFBO0lBQ3ZDLHFDQUF3QixDQUFBO0lBQ3hCLHdEQUEyQyxDQUFBO0lBQzNDLDBDQUE2QixDQUFBO0lBQzdCLDRDQUErQixDQUFBO0lBQy9CLHNEQUF5QyxDQUFBO0FBQzNDLENBQUMsRUF0QlcsU0FBUyxLQUFULFNBQVMsUUFzQnBCIn0=