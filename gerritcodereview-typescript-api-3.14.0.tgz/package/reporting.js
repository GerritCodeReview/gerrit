/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
export var Deduping;
(function (Deduping) {
    /**
     * Only report the event once per session, even if the event details are
     * different.
     */
    Deduping["EVENT_ONCE_PER_SESSION"] = "EVENT_ONCE_PER_SESSION";
    /**
     * Only report the event once per change, even if the event details are
     * different.
     */
    Deduping["EVENT_ONCE_PER_CHANGE"] = "EVENT_ONCE_PER_CHANGE";
    /** Only report these exact event details once per session. */
    Deduping["DETAILS_ONCE_PER_SESSION"] = "DETAILS_ONCE_PER_SESSION";
    /** Only report these exact event details once per change. */
    Deduping["DETAILS_ONCE_PER_CHANGE"] = "DETAILS_ONCE_PER_CHANGE";
})(Deduping || (Deduping = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVwb3J0aW5nLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicmVwb3J0aW5nLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7O0dBSUc7QUFLSCxNQUFNLENBQU4sSUFBWSxRQWVYO0FBZkQsV0FBWSxRQUFRO0lBQ2xCOzs7T0FHRztJQUNILDZEQUFpRCxDQUFBO0lBQ2pEOzs7T0FHRztJQUNILDJEQUErQyxDQUFBO0lBQy9DLDhEQUE4RDtJQUM5RCxpRUFBcUQsQ0FBQTtJQUNyRCw2REFBNkQ7SUFDN0QsK0RBQW1ELENBQUE7QUFDckQsQ0FBQyxFQWZXLFFBQVEsS0FBUixRQUFRLFFBZW5CIn0=