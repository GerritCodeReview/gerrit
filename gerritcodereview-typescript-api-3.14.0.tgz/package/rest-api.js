/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * rest-api.ts contains all entities from the Gerrit REST API that are also
 * relevant to plugins and gr-diff users. These entities should be exactly what
 * the backend defines and returns and should eventually be generated.
 *
 * Sorting order:
 * - enums in alphabetical order
 * - types and interfaces in alphabetical order
 *   - type checking functions after their corresponding type
 */
/**
 * enums =======================================================================
 */
/**
 * The authentication type that is configured on the server.
 * https://gerrit-review.googlesource.com/Documentation/rest-api-config.html#auth-info
 */
export var AuthType;
(function (AuthType) {
    AuthType["OPENID"] = "OPENID";
    AuthType["OPENID_SSO"] = "OPENID_SSO";
    AuthType["OAUTH"] = "OAUTH";
    AuthType["HTTP"] = "HTTP";
    AuthType["HTTP_LDAP"] = "HTTP_LDAP";
    AuthType["CLIENT_SSL_CERT_LDAP"] = "CLIENT_SSL_CERT_LDAP";
    AuthType["LDAP"] = "LDAP";
    AuthType["LDAP_BIND"] = "LDAP_BIND";
    AuthType["CUSTOM_EXTENSION"] = "CUSTOM_EXTENSION";
    AuthType["DEVELOPMENT_BECOME_ANY_ACCOUNT"] = "DEVELOPMENT_BECOME_ANY_ACCOUNT";
})(AuthType || (AuthType = {}));
/**
 * Specifies status for a change
 */
export var ChangeStatus;
(function (ChangeStatus) {
    ChangeStatus["ABANDONED"] = "ABANDONED";
    ChangeStatus["MERGED"] = "MERGED";
    ChangeStatus["NEW"] = "NEW";
})(ChangeStatus || (ChangeStatus = {}));
/**
 * The type in ConfigParameterInfo entity.
 * https://gerrit-review.googlesource.com/Documentation/rest-api-projects.html#config-parameter-info
 */
export var ConfigParameterInfoType;
(function (ConfigParameterInfoType) {
    // Should be kept in sync with
    // gerrit/java/com/google/gerrit/extensions/api/projects/ProjectConfigEntryType.java.
    ConfigParameterInfoType["STRING"] = "STRING";
    ConfigParameterInfoType["INT"] = "INT";
    ConfigParameterInfoType["LONG"] = "LONG";
    ConfigParameterInfoType["BOOLEAN"] = "BOOLEAN";
    ConfigParameterInfoType["LIST"] = "LIST";
    ConfigParameterInfoType["ARRAY"] = "ARRAY";
})(ConfigParameterInfoType || (ConfigParameterInfoType = {}));
/**
 * Used for server config of accounts
 */
export var DefaultDisplayNameConfig;
(function (DefaultDisplayNameConfig) {
    DefaultDisplayNameConfig["USERNAME"] = "USERNAME";
    DefaultDisplayNameConfig["FIRST_NAME"] = "FIRST_NAME";
    DefaultDisplayNameConfig["FULL_NAME"] = "FULL_NAME";
})(DefaultDisplayNameConfig || (DefaultDisplayNameConfig = {}));
/**
 * Account fields that are editable
 * https://gerrit-review.googlesource.com/Documentation/rest-api-config.html#auth-info
 */
export var EditableAccountField;
(function (EditableAccountField) {
    EditableAccountField["FULL_NAME"] = "FULL_NAME";
    EditableAccountField["USER_NAME"] = "USER_NAME";
    EditableAccountField["REGISTER_NEW_EMAIL"] = "REGISTER_NEW_EMAIL";
})(EditableAccountField || (EditableAccountField = {}));
/**
 * The status of the file
 */
export var FileInfoStatus;
(function (FileInfoStatus) {
    FileInfoStatus["ADDED"] = "A";
    FileInfoStatus["DELETED"] = "D";
    FileInfoStatus["RENAMED"] = "R";
    FileInfoStatus["COPIED"] = "C";
    FileInfoStatus["REWRITTEN"] = "W";
    FileInfoStatus["MODIFIED"] = "M";
    FileInfoStatus["UNMODIFIED"] = "U";
    FileInfoStatus["REVERTED"] = "X";
})(FileInfoStatus || (FileInfoStatus = {}));
/**
 * The status of the file
 */
export var GpgKeyInfoStatus;
(function (GpgKeyInfoStatus) {
    GpgKeyInfoStatus["BAD"] = "BAD";
    GpgKeyInfoStatus["OK"] = "OK";
    GpgKeyInfoStatus["TRUSTED"] = "TRUSTED";
})(GpgKeyInfoStatus || (GpgKeyInfoStatus = {}));
/**
 * Enum for all http methods used in Gerrit.
 */
export var HttpMethod;
(function (HttpMethod) {
    HttpMethod["HEAD"] = "HEAD";
    HttpMethod["POST"] = "POST";
    HttpMethod["GET"] = "GET";
    HttpMethod["DELETE"] = "DELETE";
    HttpMethod["PUT"] = "PUT";
})(HttpMethod || (HttpMethod = {}));
/**
 * Enum for possible configured value in InheritedBooleanInfo.
 * https://gerrit-review.googlesource.com/Documentation/rest-api-projects.html#inherited-boolean-info
 */
export var InheritedBooleanInfoConfiguredValue;
(function (InheritedBooleanInfoConfiguredValue) {
    InheritedBooleanInfoConfiguredValue["TRUE"] = "TRUE";
    InheritedBooleanInfoConfiguredValue["FALSE"] = "FALSE";
    InheritedBooleanInfoConfiguredValue["INHERIT"] = "INHERIT";
})(InheritedBooleanInfoConfiguredValue || (InheritedBooleanInfoConfiguredValue = {}));
/**
 * This setting determines when Gerrit computes if a change is mergeable or not.
 * https://gerrit-review.googlesource.com/Documentation/config-gerrit.html#change.mergeabilityComputationBehavior
 */
export var MergeabilityComputationBehavior;
(function (MergeabilityComputationBehavior) {
    MergeabilityComputationBehavior["API_REF_UPDATED_AND_CHANGE_REINDEX"] = "API_REF_UPDATED_AND_CHANGE_REINDEX";
    MergeabilityComputationBehavior["REF_UPDATED_AND_CHANGE_REINDEX"] = "REF_UPDATED_AND_CHANGE_REINDEX";
    MergeabilityComputationBehavior["NEVER"] = "NEVER";
})(MergeabilityComputationBehavior || (MergeabilityComputationBehavior = {}));
/**
 * The status of fixing the problem
 */
export var ProblemInfoStatus;
(function (ProblemInfoStatus) {
    ProblemInfoStatus["FIXED"] = "FIXED";
    ProblemInfoStatus["FIX_FAILED"] = "FIX_FAILED";
})(ProblemInfoStatus || (ProblemInfoStatus = {}));
/**
 * The state of the repository
 */
export var RepoState;
(function (RepoState) {
    RepoState["ACTIVE"] = "ACTIVE";
    RepoState["READ_ONLY"] = "READ_ONLY";
    RepoState["HIDDEN"] = "HIDDEN";
})(RepoState || (RepoState = {}));
/**
 * The reviewer state
 */
export var RequirementStatus;
(function (RequirementStatus) {
    RequirementStatus["OK"] = "OK";
    RequirementStatus["NOT_READY"] = "NOT_READY";
    RequirementStatus["RULE_ERROR"] = "RULE_ERROR";
})(RequirementStatus || (RequirementStatus = {}));
/**
 * The reviewer state
 */
export var ReviewerState;
(function (ReviewerState) {
    ReviewerState["REVIEWER"] = "REVIEWER";
    ReviewerState["CC"] = "CC";
    ReviewerState["REMOVED"] = "REMOVED";
})(ReviewerState || (ReviewerState = {}));
/**
 * The patchset kind
 */
export var RevisionKind;
(function (RevisionKind) {
    RevisionKind["REWORK"] = "REWORK";
    RevisionKind["TRIVIAL_REBASE"] = "TRIVIAL_REBASE";
    RevisionKind["TRIVIAL_REBASE_WITH_MESSAGE_UPDATE"] = "TRIVIAL_REBASE_WITH_MESSAGE_UPDATE";
    RevisionKind["MERGE_FIRST_PARENT_UPDATE"] = "MERGE_FIRST_PARENT_UPDATE";
    RevisionKind["NO_CODE_CHANGE"] = "NO_CODE_CHANGE";
    RevisionKind["NO_CHANGE"] = "NO_CHANGE";
})(RevisionKind || (RevisionKind = {}));
/**
 * All supported submit types.
 * https://gerrit-review.googlesource.com/Documentation/rest-api-projects.html#submit-type-info
 */
export var SubmitType;
(function (SubmitType) {
    SubmitType["MERGE_IF_NECESSARY"] = "MERGE_IF_NECESSARY";
    SubmitType["FAST_FORWARD_ONLY"] = "FAST_FORWARD_ONLY";
    SubmitType["REBASE_IF_NECESSARY"] = "REBASE_IF_NECESSARY";
    SubmitType["REBASE_ALWAYS"] = "REBASE_ALWAYS";
    SubmitType["MERGE_ALWAYS"] = "MERGE_ALWAYS ";
    SubmitType["CHERRY_PICK"] = "CHERRY_PICK";
    SubmitType["INHERIT"] = "INHERIT";
})(SubmitType || (SubmitType = {}));
/**
 * The state of a flow stage.
 */
export var FlowStageState;
(function (FlowStageState) {
    FlowStageState["DONE"] = "DONE";
    FlowStageState["FAILED"] = "FAILED";
    FlowStageState["PENDING"] = "PENDING";
    FlowStageState["TERMINATED"] = "TERMINATED";
})(FlowStageState || (FlowStageState = {}));
/**
 * The side on which the comment was added
 * https://gerrit-review.googlesource.com/Documentation/rest-api-changes.html#comment-info
 */
export var CommentSide;
(function (CommentSide) {
    CommentSide["REVISION"] = "REVISION";
    CommentSide["PARENT"] = "PARENT";
})(CommentSide || (CommentSide = {}));
export function isDetailedLabelInfo(label) {
    return !!label.values;
}
export const EDIT = 'edit';
export const PARENT = 'PARENT';
export const FIRST_PARENT = -1;
/**
 * Same as `PARENT`, but marks it as an explicit user choice, so that the
 * `default_base_for_merges` preference does not override it. It is encoded as
 * `0` in the URL and normalized back to `PARENT` by the change model, so it
 * never reaches the REST API or any view. See `computeBase()`.
 */
export const AUTO_MERGE = 'AUTO_MERGE';
export function isQuickLabelInfo(l) {
    const quickLabelInfo = l;
    return (quickLabelInfo.approved !== undefined ||
        quickLabelInfo.rejected !== undefined ||
        quickLabelInfo.recommended !== undefined ||
        quickLabelInfo.disliked !== undefined ||
        quickLabelInfo.blocking !== undefined ||
        quickLabelInfo.blocking !== undefined ||
        quickLabelInfo.value !== undefined);
}
export var SubmitRequirementExpressionInfoStatus;
(function (SubmitRequirementExpressionInfoStatus) {
    SubmitRequirementExpressionInfoStatus["PASS"] = "PASS";
    SubmitRequirementExpressionInfoStatus["FAIL"] = "FAIL";
    SubmitRequirementExpressionInfoStatus["ERROR"] = "ERROR";
    SubmitRequirementExpressionInfoStatus["NOT_EVALUATED"] = "NOT_EVALUATED";
    SubmitRequirementExpressionInfoStatus["TIMEOUT"] = "TIMEOUT";
})(SubmitRequirementExpressionInfoStatus || (SubmitRequirementExpressionInfoStatus = {}));
/**
 * Status describing the result of evaluating the submit requirement.
 * https://gerrit-review.googlesource.com/Documentation/rest-api-changes.html#submit-requirement-result-info
 */
export var SubmitRequirementStatus;
(function (SubmitRequirementStatus) {
    SubmitRequirementStatus["SATISFIED"] = "SATISFIED";
    SubmitRequirementStatus["UNSATISFIED"] = "UNSATISFIED";
    SubmitRequirementStatus["OVERRIDDEN"] = "OVERRIDDEN";
    SubmitRequirementStatus["NOT_APPLICABLE"] = "NOT_APPLICABLE";
    SubmitRequirementStatus["ERROR"] = "ERROR";
    SubmitRequirementStatus["FORCED"] = "FORCED";
    SubmitRequirementStatus["TIMEOUT"] = "TIMEOUT";
})(SubmitRequirementStatus || (SubmitRequirementStatus = {}));
export var SubmitRecordInfoStatus;
(function (SubmitRecordInfoStatus) {
    SubmitRecordInfoStatus["OK"] = "OK";
    SubmitRecordInfoStatus["NOT_READY"] = "NOT_READY";
    SubmitRecordInfoStatus["CLOSED"] = "CLOSED";
    SubmitRecordInfoStatus["FORCED"] = "FORCED";
    SubmitRecordInfoStatus["RULE_ERROR"] = "RULE_ERROR";
})(SubmitRecordInfoStatus || (SubmitRecordInfoStatus = {}));
export var LabelStatus;
(function (LabelStatus) {
    /**
     * This label provides what is necessary for submission.
     */
    LabelStatus["OK"] = "OK";
    /**
     * This label prevents the change from being submitted.
     */
    LabelStatus["REJECT"] = "REJECT";
    /**
     * The label may be set, but it's neither necessary for submission
     * nor does it block submission if set.
     */
    LabelStatus["MAY"] = "MAY";
    /**
     * The label is required for submission, but has not been satisfied.
     */
    LabelStatus["NEED"] = "NEED";
    /**
     * The label is required for submission, but is impossible to complete.
     * The likely cause is access has not been granted correctly by the
     * repository owner or site administrator.
     */
    LabelStatus["IMPOSSIBLE"] = "IMPOSSIBLE";
    LabelStatus["OPTIONAL"] = "OPTIONAL";
})(LabelStatus || (LabelStatus = {}));
export function isBase64FileContent(res) {
    return res.ok;
}
export var LabelDefinitionInfoFunction;
(function (LabelDefinitionInfoFunction) {
    LabelDefinitionInfoFunction["MaxWithBlock"] = "MaxWithBlock";
    LabelDefinitionInfoFunction["AnyWithBlock"] = "AnyWithBlock";
    LabelDefinitionInfoFunction["MaxNoBlock"] = "MaxNoBlock";
    LabelDefinitionInfoFunction["NoBlock"] = "NoBlock";
    LabelDefinitionInfoFunction["NoOp"] = "NoOp";
    LabelDefinitionInfoFunction["PatchSetLock"] = "PatchSetLock";
})(LabelDefinitionInfoFunction || (LabelDefinitionInfoFunction = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVzdC1hcGkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJyZXN0LWFwaS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7OztHQUlHO0FBRUg7Ozs7Ozs7OztHQVNHO0FBRUg7O0dBRUc7QUFFSDs7O0dBR0c7QUFDSCxNQUFNLENBQU4sSUFBWSxRQVdYO0FBWEQsV0FBWSxRQUFRO0lBQ2xCLDZCQUFpQixDQUFBO0lBQ2pCLHFDQUF5QixDQUFBO0lBQ3pCLDJCQUFlLENBQUE7SUFDZix5QkFBYSxDQUFBO0lBQ2IsbUNBQXVCLENBQUE7SUFDdkIseURBQTZDLENBQUE7SUFDN0MseUJBQWEsQ0FBQTtJQUNiLG1DQUF1QixDQUFBO0lBQ3ZCLGlEQUFxQyxDQUFBO0lBQ3JDLDZFQUFpRSxDQUFBO0FBQ25FLENBQUMsRUFYVyxRQUFRLEtBQVIsUUFBUSxRQVduQjtBQUVEOztHQUVHO0FBQ0gsTUFBTSxDQUFOLElBQVksWUFJWDtBQUpELFdBQVksWUFBWTtJQUN0Qix1Q0FBdUIsQ0FBQTtJQUN2QixpQ0FBaUIsQ0FBQTtJQUNqQiwyQkFBVyxDQUFBO0FBQ2IsQ0FBQyxFQUpXLFlBQVksS0FBWixZQUFZLFFBSXZCO0FBRUQ7OztHQUdHO0FBQ0gsTUFBTSxDQUFOLElBQVksdUJBU1g7QUFURCxXQUFZLHVCQUF1QjtJQUNqQyw4QkFBOEI7SUFDOUIscUZBQXFGO0lBQ3JGLDRDQUFpQixDQUFBO0lBQ2pCLHNDQUFXLENBQUE7SUFDWCx3Q0FBYSxDQUFBO0lBQ2IsOENBQW1CLENBQUE7SUFDbkIsd0NBQWEsQ0FBQTtJQUNiLDBDQUFlLENBQUE7QUFDakIsQ0FBQyxFQVRXLHVCQUF1QixLQUF2Qix1QkFBdUIsUUFTbEM7QUFFRDs7R0FFRztBQUNILE1BQU0sQ0FBTixJQUFZLHdCQUlYO0FBSkQsV0FBWSx3QkFBd0I7SUFDbEMsaURBQXFCLENBQUE7SUFDckIscURBQXlCLENBQUE7SUFDekIsbURBQXVCLENBQUE7QUFDekIsQ0FBQyxFQUpXLHdCQUF3QixLQUF4Qix3QkFBd0IsUUFJbkM7QUFFRDs7O0dBR0c7QUFDSCxNQUFNLENBQU4sSUFBWSxvQkFJWDtBQUpELFdBQVksb0JBQW9CO0lBQzlCLCtDQUF1QixDQUFBO0lBQ3ZCLCtDQUF1QixDQUFBO0lBQ3ZCLGlFQUF5QyxDQUFBO0FBQzNDLENBQUMsRUFKVyxvQkFBb0IsS0FBcEIsb0JBQW9CLFFBSS9CO0FBRUQ7O0dBRUc7QUFDSCxNQUFNLENBQU4sSUFBWSxjQVNYO0FBVEQsV0FBWSxjQUFjO0lBQ3hCLDZCQUFXLENBQUE7SUFDWCwrQkFBYSxDQUFBO0lBQ2IsK0JBQWEsQ0FBQTtJQUNiLDhCQUFZLENBQUE7SUFDWixpQ0FBZSxDQUFBO0lBQ2YsZ0NBQWMsQ0FBQTtJQUNkLGtDQUFnQixDQUFBO0lBQ2hCLGdDQUFjLENBQUE7QUFDaEIsQ0FBQyxFQVRXLGNBQWMsS0FBZCxjQUFjLFFBU3pCO0FBRUQ7O0dBRUc7QUFDSCxNQUFNLENBQU4sSUFBWSxnQkFJWDtBQUpELFdBQVksZ0JBQWdCO0lBQzFCLCtCQUFXLENBQUE7SUFDWCw2QkFBUyxDQUFBO0lBQ1QsdUNBQW1CLENBQUE7QUFDckIsQ0FBQyxFQUpXLGdCQUFnQixLQUFoQixnQkFBZ0IsUUFJM0I7QUFFRDs7R0FFRztBQUNILE1BQU0sQ0FBTixJQUFZLFVBTVg7QUFORCxXQUFZLFVBQVU7SUFDcEIsMkJBQWEsQ0FBQTtJQUNiLDJCQUFhLENBQUE7SUFDYix5QkFBVyxDQUFBO0lBQ1gsK0JBQWlCLENBQUE7SUFDakIseUJBQVcsQ0FBQTtBQUNiLENBQUMsRUFOVyxVQUFVLEtBQVYsVUFBVSxRQU1yQjtBQUVEOzs7R0FHRztBQUNILE1BQU0sQ0FBTixJQUFZLG1DQUlYO0FBSkQsV0FBWSxtQ0FBbUM7SUFDN0Msb0RBQWEsQ0FBQTtJQUNiLHNEQUFlLENBQUE7SUFDZiwwREFBbUIsQ0FBQTtBQUNyQixDQUFDLEVBSlcsbUNBQW1DLEtBQW5DLG1DQUFtQyxRQUk5QztBQUVEOzs7R0FHRztBQUNILE1BQU0sQ0FBTixJQUFZLCtCQUlYO0FBSkQsV0FBWSwrQkFBK0I7SUFDekMsNEdBQXlFLENBQUE7SUFDekUsb0dBQWlFLENBQUE7SUFDakUsa0RBQWUsQ0FBQTtBQUNqQixDQUFDLEVBSlcsK0JBQStCLEtBQS9CLCtCQUErQixRQUkxQztBQUVEOztHQUVHO0FBQ0gsTUFBTSxDQUFOLElBQVksaUJBR1g7QUFIRCxXQUFZLGlCQUFpQjtJQUMzQixvQ0FBZSxDQUFBO0lBQ2YsOENBQXlCLENBQUE7QUFDM0IsQ0FBQyxFQUhXLGlCQUFpQixLQUFqQixpQkFBaUIsUUFHNUI7QUFFRDs7R0FFRztBQUNILE1BQU0sQ0FBTixJQUFZLFNBSVg7QUFKRCxXQUFZLFNBQVM7SUFDbkIsOEJBQWlCLENBQUE7SUFDakIsb0NBQXVCLENBQUE7SUFDdkIsOEJBQWlCLENBQUE7QUFDbkIsQ0FBQyxFQUpXLFNBQVMsS0FBVCxTQUFTLFFBSXBCO0FBRUQ7O0dBRUc7QUFDSCxNQUFNLENBQU4sSUFBWSxpQkFJWDtBQUpELFdBQVksaUJBQWlCO0lBQzNCLDhCQUFTLENBQUE7SUFDVCw0Q0FBdUIsQ0FBQTtJQUN2Qiw4Q0FBeUIsQ0FBQTtBQUMzQixDQUFDLEVBSlcsaUJBQWlCLEtBQWpCLGlCQUFpQixRQUk1QjtBQUVEOztHQUVHO0FBQ0gsTUFBTSxDQUFOLElBQVksYUFJWDtBQUpELFdBQVksYUFBYTtJQUN2QixzQ0FBcUIsQ0FBQTtJQUNyQiwwQkFBUyxDQUFBO0lBQ1Qsb0NBQW1CLENBQUE7QUFDckIsQ0FBQyxFQUpXLGFBQWEsS0FBYixhQUFhLFFBSXhCO0FBRUQ7O0dBRUc7QUFDSCxNQUFNLENBQU4sSUFBWSxZQU9YO0FBUEQsV0FBWSxZQUFZO0lBQ3RCLGlDQUFpQixDQUFBO0lBQ2pCLGlEQUFpQyxDQUFBO0lBQ2pDLHlGQUF5RSxDQUFBO0lBQ3pFLHVFQUF1RCxDQUFBO0lBQ3ZELGlEQUFpQyxDQUFBO0lBQ2pDLHVDQUF1QixDQUFBO0FBQ3pCLENBQUMsRUFQVyxZQUFZLEtBQVosWUFBWSxRQU92QjtBQUVEOzs7R0FHRztBQUNILE1BQU0sQ0FBTixJQUFZLFVBUVg7QUFSRCxXQUFZLFVBQVU7SUFDcEIsdURBQXlDLENBQUE7SUFDekMscURBQXVDLENBQUE7SUFDdkMseURBQTJDLENBQUE7SUFDM0MsNkNBQStCLENBQUE7SUFDL0IsNENBQThCLENBQUE7SUFDOUIseUNBQTJCLENBQUE7SUFDM0IsaUNBQW1CLENBQUE7QUFDckIsQ0FBQyxFQVJXLFVBQVUsS0FBVixVQUFVLFFBUXJCO0FBRUQ7O0dBRUc7QUFDSCxNQUFNLENBQU4sSUFBWSxjQUtYO0FBTEQsV0FBWSxjQUFjO0lBQ3hCLCtCQUFhLENBQUE7SUFDYixtQ0FBaUIsQ0FBQTtJQUNqQixxQ0FBbUIsQ0FBQTtJQUNuQiwyQ0FBeUIsQ0FBQTtBQUMzQixDQUFDLEVBTFcsY0FBYyxLQUFkLGNBQWMsUUFLekI7QUFtWUQ7OztHQUdHO0FBQ0gsTUFBTSxDQUFOLElBQVksV0FHWDtBQUhELFdBQVksV0FBVztJQUNyQixvQ0FBcUIsQ0FBQTtJQUNyQixnQ0FBaUIsQ0FBQTtBQUNuQixDQUFDLEVBSFcsV0FBVyxLQUFYLFdBQVcsUUFHdEI7QUE0REQsTUFBTSxVQUFVLG1CQUFtQixDQUNqQyxLQUFnQjtJQUVoQixPQUFPLENBQUMsQ0FBRSxLQUEyQixDQUFDLE1BQU0sQ0FBQztBQUMvQyxDQUFDO0FBMFNELE1BQU0sQ0FBQyxNQUFNLElBQUksR0FBRyxNQUFzQixDQUFDO0FBSTNDLE1BQU0sQ0FBQyxNQUFNLE1BQU0sR0FBRyxRQUEwQixDQUFDO0FBQ2pELE1BQU0sQ0FBQyxNQUFNLFlBQVksR0FBRyxDQUFDLENBQW1CLENBQUM7QUFFakQ7Ozs7O0dBS0c7QUFDSCxNQUFNLENBQUMsTUFBTSxVQUFVLEdBQUcsWUFBOEIsQ0FBQztBQTZGekQsTUFBTSxVQUFVLGdCQUFnQixDQUM5QixDQUFZO0lBRVosTUFBTSxjQUFjLEdBQUcsQ0FBbUIsQ0FBQztJQUMzQyxPQUFPLENBQ0wsY0FBYyxDQUFDLFFBQVEsS0FBSyxTQUFTO1FBQ3JDLGNBQWMsQ0FBQyxRQUFRLEtBQUssU0FBUztRQUNyQyxjQUFjLENBQUMsV0FBVyxLQUFLLFNBQVM7UUFDeEMsY0FBYyxDQUFDLFFBQVEsS0FBSyxTQUFTO1FBQ3JDLGNBQWMsQ0FBQyxRQUFRLEtBQUssU0FBUztRQUNyQyxjQUFjLENBQUMsUUFBUSxLQUFLLFNBQVM7UUFDckMsY0FBYyxDQUFDLEtBQUssS0FBSyxTQUFTLENBQ25DLENBQUM7QUFDSixDQUFDO0FBd1FELE1BQU0sQ0FBTixJQUFZLHFDQU1YO0FBTkQsV0FBWSxxQ0FBcUM7SUFDL0Msc0RBQWEsQ0FBQTtJQUNiLHNEQUFhLENBQUE7SUFDYix3REFBZSxDQUFBO0lBQ2Ysd0VBQStCLENBQUE7SUFDL0IsNERBQW1CLENBQUE7QUFDckIsQ0FBQyxFQU5XLHFDQUFxQyxLQUFyQyxxQ0FBcUMsUUFNaEQ7QUFFRDs7O0dBR0c7QUFDSCxNQUFNLENBQU4sSUFBWSx1QkFRWDtBQVJELFdBQVksdUJBQXVCO0lBQ2pDLGtEQUF1QixDQUFBO0lBQ3ZCLHNEQUEyQixDQUFBO0lBQzNCLG9EQUF5QixDQUFBO0lBQ3pCLDREQUFpQyxDQUFBO0lBQ2pDLDBDQUFlLENBQUE7SUFDZiw0Q0FBaUIsQ0FBQTtJQUNqQiw4Q0FBbUIsQ0FBQTtBQUNyQixDQUFDLEVBUlcsdUJBQXVCLEtBQXZCLHVCQUF1QixRQVFsQztBQWdCRCxNQUFNLENBQU4sSUFBWSxzQkFNWDtBQU5ELFdBQVksc0JBQXNCO0lBQ2hDLG1DQUFTLENBQUE7SUFDVCxpREFBdUIsQ0FBQTtJQUN2QiwyQ0FBaUIsQ0FBQTtJQUNqQiwyQ0FBaUIsQ0FBQTtJQUNqQixtREFBeUIsQ0FBQTtBQUMzQixDQUFDLEVBTlcsc0JBQXNCLEtBQXRCLHNCQUFzQixRQU1qQztBQUVELE1BQU0sQ0FBTixJQUFZLFdBeUJYO0FBekJELFdBQVksV0FBVztJQUNyQjs7T0FFRztJQUNILHdCQUFTLENBQUE7SUFDVDs7T0FFRztJQUNILGdDQUFpQixDQUFBO0lBQ2pCOzs7T0FHRztJQUNILDBCQUFXLENBQUE7SUFDWDs7T0FFRztJQUNILDRCQUFhLENBQUE7SUFDYjs7OztPQUlHO0lBQ0gsd0NBQXlCLENBQUE7SUFDekIsb0NBQXFCLENBQUE7QUFDdkIsQ0FBQyxFQXpCVyxXQUFXLEtBQVgsV0FBVyxRQXlCdEI7QUFxQkQsTUFBTSxVQUFVLG1CQUFtQixDQUNqQyxHQUFpQztJQUVqQyxPQUFRLEdBQXlCLENBQUMsRUFBRSxDQUFDO0FBQ3ZDLENBQUM7QUFvREQsTUFBTSxDQUFOLElBQVksMkJBT1g7QUFQRCxXQUFZLDJCQUEyQjtJQUNyQyw0REFBNkIsQ0FBQTtJQUM3Qiw0REFBNkIsQ0FBQTtJQUM3Qix3REFBeUIsQ0FBQTtJQUN6QixrREFBbUIsQ0FBQTtJQUNuQiw0Q0FBYSxDQUFBO0lBQ2IsNERBQTZCLENBQUE7QUFDL0IsQ0FBQyxFQVBXLDJCQUEyQixLQUEzQiwyQkFBMkIsUUFPdEMifQ==