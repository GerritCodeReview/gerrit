/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
import { HttpMethod, } from './rest-api';
export { HttpMethod };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVzdC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInJlc3QudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7R0FJRztBQUNILE9BQU8sRUFFTCxVQUFVLEdBR1gsTUFBTSxZQUFZLENBQUM7QUFFcEIsT0FBTyxFQUFDLFVBQVUsRUFBQyxDQUFDIn0=