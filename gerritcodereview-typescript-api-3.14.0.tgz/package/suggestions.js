/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
export var ResponseCode;
(function (ResponseCode) {
    ResponseCode["OK"] = "OK";
    ResponseCode["NO_SUGGESTION"] = "NO_SUGGESTION";
    ResponseCode["OUT_OF_RANGE"] = "OUT_OF_RANGE";
    ResponseCode["ERROR"] = "ERROR";
    ResponseCode["FILE_TOO_LARGE"] = "FILE_TOO_LARGE";
    ResponseCode["INVALID_RANGE"] = "INVALID_RANGE";
    ResponseCode["UNSUPPORTED_FILE_TYPE"] = "UNSUPPORTED_FILE_TYPE";
    ResponseCode["USER_QUOTA_EXCEEDED"] = "USER_QUOTA_EXCEEDED";
    ResponseCode["OK_LOW_CONFIDENCE"] = "OK_LOW_CONFIDENCE";
})(ResponseCode || (ResponseCode = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3VnZ2VzdGlvbnMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJzdWdnZXN0aW9ucy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7OztHQUlHO0FBeUhILE1BQU0sQ0FBTixJQUFZLFlBVVg7QUFWRCxXQUFZLFlBQVk7SUFDdEIseUJBQVMsQ0FBQTtJQUNULCtDQUErQixDQUFBO0lBQy9CLDZDQUE2QixDQUFBO0lBQzdCLCtCQUFlLENBQUE7SUFDZixpREFBaUMsQ0FBQTtJQUNqQywrQ0FBK0IsQ0FBQTtJQUMvQiwrREFBK0MsQ0FBQTtJQUMvQywyREFBMkMsQ0FBQTtJQUMzQyx1REFBdUMsQ0FBQTtBQUN6QyxDQUFDLEVBVlcsWUFBWSxLQUFaLFlBQVksUUFVdkIifQ==